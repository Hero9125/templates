var DragCheck = require('./dragcheck').DragCheck;

window.DragCheck = DragCheck;